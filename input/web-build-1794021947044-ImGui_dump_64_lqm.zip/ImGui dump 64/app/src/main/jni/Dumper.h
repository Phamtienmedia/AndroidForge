


#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <cstring>
#include <jni.h>

size_t read_memory(void *addr, size_t bytesToRead, FILE *output_fp) {
    mlock(addr, bytesToRead);

    size_t bytesWritten = fwrite(addr, 1, bytesToRead, output_fp);
    return bytesWritten;
}



void dumpMemory(const char* libName, const char* outputFilePath) {
    FILE *fp = fopen(OBFUSCATE("/proc/self/maps"), OBFUSCATE("rt"));
    if (fp == NULL) {
        return;
    }

    unsigned long startAddr = 0;
    unsigned long endAddr = 0;
    char perms[5];
    char line[512];

    FILE *output_fp = fopen(outputFilePath, "wb");
    if (output_fp == NULL) {
        fclose(fp);
        return;
    }

    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strstr(line, libName) != NULL) {
            sscanf(line, "%lx-%lx %4s", &startAddr, &endAddr, perms);

            for (unsigned long addr = startAddr; addr < endAddr; addr += 4096) {
                size_t bytesToRead = (size_t)((endAddr - addr) < 4096 ? (endAddr - addr) : 4096);
                size_t bytesRead = read_memory((void*)addr, bytesToRead, output_fp);
                if (bytesRead == 0) {
                    break;
                }
            }
        }
    }

    fclose(fp);
    fclose(output_fp);
}




const char *GetPackageNameH() {
    char *application_id[256];
    FILE *fp = fopen("proc/self/cmdline", "r");
    if (fp) {
        fread(application_id, sizeof(application_id), 1, fp);
        fclose(fp);
    }
    return (const char *) application_id;
}

std::string SaveCustom(const char* fileName) {
    
    

  std::string filePath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/").append(fileName);
//const char *output_dir = filePath.c_str();
    
    return filePath; // Trả về std::string (an toàn, không bị invalid)
}


int SaveLib(JNIEnv* env, jobject context, const char* libName) {
    const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
	std::string directoryPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/1.bin");
	const char *output_dir = directoryPath.c_str();
    
	snprintf(filePath, sizeof(filePath), output_dir, packageNameCStr);
    dumpMemory(libName, filePath);
    return 0;
}




int SaveLib3(const char* libName) {
    const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
	std::string directoryPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/il2.bin");
	const char *output_dir = directoryPath.c_str();
    
	snprintf(filePath, sizeof(filePath), output_dir, packageNameCStr);
    dumpMemory(libName, filePath);
    return 0;
}



int SaveLib4(const char* libName) {
    const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
	std::string directoryPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/anog.bin");
	const char *output_dir = directoryPath.c_str();
    
	snprintf(filePath, sizeof(filePath), output_dir, packageNameCStr);
    dumpMemory(libName, filePath);
    return 0;
}


int SaveLib2(JNIEnv* env, jobject context, const char* libName) {
    const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
	std::string directoryPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/2.bin");
	const char *output_dir = directoryPath.c_str();
    
	snprintf(filePath, sizeof(filePath), output_dir, packageNameCStr);
    dumpMemory(libName, filePath);
    return 0;
}



bool dumpok;


void showToast(JNIEnv *env, jobject context, const char *message) {
    jclass toastClass = env->FindClass("android/widget/Toast");
    jmethodID makeTextMethod = env->GetStaticMethodID(toastClass, "makeText", 
        "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    jmethodID showMethod = env->GetMethodID(toastClass, "show", "()V");

    jstring jMessage = env->NewStringUTF(message);
    jobject toast = env->CallStaticObjectMethod(toastClass, makeTextMethod, context, jMessage, 1);
    env->CallVoidMethod(toast, showMethod);
}








/*void compareFiles(const std::string& originalFile, const std::string& modifiedFile, const std::string& outputFile, JNIEnv *env, jobject context) {
    std::ifstream original(originalFile, std::ios::binary);
    std::ifstream modified(modifiedFile, std::ios::binary);
    std::ofstream output(outputFile);

    if (!original.is_open() || !modified.is_open() || !output.is_open()) {
        std::cerr << "Error opening files." << std::endl;
        return;
    }

    std::vector<char> originalBuffer(std::istreambuf_iterator<char>(original), {});
    std::vector<char> modifiedBuffer(std::istreambuf_iterator<char>(modified), {});

    size_t minSize = std::min(originalBuffer.size(), modifiedBuffer.size());
    bool foundDifference = false;

    std::vector<std::string> hexValues;
    size_t currentOffset = 0;
    int lineNumber = 1; // Khởi tạo biến đếm số dòng

    for (size_t i = 0; i < minSize; ++i) {
        if (originalBuffer[i] != modifiedBuffer[i]) {
            if (!foundDifference) {
                currentOffset = i; // Lưu offset đầu tiên
                hexValues.clear(); // Xóa các giá trị hex cũ
                foundDifference = true;
            }

            // Tạo chuỗi hex từ byte modified
            std::ostringstream hexStream;
            hexStream << std::setw(2) << std::setfill('0') << std::hex << (unsigned int)(unsigned char)modifiedBuffer[i];
            hexValues.push_back(hexStream.str());

            // Nếu đã có 16 giá trị, xuất ra
            if (hexValues.size() == 16) {
                output << "[" << lineNumber++ << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
                for (const auto& hex : hexValues) {
                    output << hex << " ";
                }
                output << std::endl;

                // Đặt lại cờ để tìm offset tiếp theo
                foundDifference = false; // Đặt lại cờ
            }
        } else {
            // Nếu không còn khác biệt và có giá trị hex đã tìm thấy, xuất ra
            if (foundDifference) {
                output << "[" << lineNumber++ << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
                for (const auto& hex : hexValues) {
                    output << hex << " ";
                }
                output << std::endl;

                // Đặt lại cờ cho lần phát hiện khác biệt tiếp theo
                foundDifference = false; // Đặt lại cờ
            }
        }
    }

    // Xuất ra nếu còn giá trị hex chưa đủ 16
    if (foundDifference && !hexValues.empty()) {
        output << "[" << lineNumber++ << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
        for (const auto& hex : hexValues) {
            output << hex << " ";
        }
        output << std::endl;
    }
    
    showToast(env, context, "Dump Successful");
    if (originalBuffer.size() != modifiedBuffer.size()) {
        output << "File sizes differ: Original size: " << originalBuffer.size() 
               << ", Modified size: " << modifiedBuffer.size() << std::endl;
    }

    original.close();
    modified.close();
    output.close();
}


*/




void compareFiles(const std::string& originalFile, const std::string& modifiedFile, const std::string& outputFile, JNIEnv *env, jobject context) {
    std::ifstream original(originalFile, std::ios::binary);
    std::ifstream modified(modifiedFile, std::ios::binary);
    std::ofstream output(outputFile);

    if (!original.is_open() || !modified.is_open() || !output.is_open()) {
        std::cerr << "Error opening files." << std::endl;
        showToast(env, context, "Error opening files.");
        return;
    }

    std::vector<char> originalBuffer(std::istreambuf_iterator<char>(original), {});
    std::vector<char> modifiedBuffer(std::istreambuf_iterator<char>(modified), {});

    size_t minSize = std::min(originalBuffer.size(), modifiedBuffer.size());
    bool foundDifference = false;

    std::vector<std::string> hexValues;
    size_t currentOffset = 0;
    int lineNumber = 1;

    for (size_t i = 0; i < minSize; ++i) {
        if (originalBuffer[i] != modifiedBuffer[i]) {
            if (!foundDifference) {
                currentOffset = i; // Lưu offset đầu tiên
                hexValues.clear(); // Xóa các giá trị hex cũ
                foundDifference = true;
            }

            // Tạo chuỗi hex từ byte modified
            std::ostringstream hexStream;
            hexStream << std::setw(2) << std::setfill('0') << std::hex << (unsigned int)(unsigned char)modifiedBuffer[i];
            hexValues.push_back(hexStream.str());

            // Nếu đã có 16 giá trị, xuất ra
            if (hexValues.size() == 16) {
                output << "[" << lineNumber << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
                for (const auto& hex : hexValues) {
                    output << hex << " ";
                }
                output << std::endl;
                lineNumber++; // Tăng lineNumber chỉ khi xuất ra

                // Đặt lại cờ để tìm offset tiếp theo
                foundDifference = false; // Đặt lại cờ
            }
        } else {
            // Nếu không còn khác biệt và có giá trị hex đã tìm thấy, xuất ra
            if (foundDifference) {
                output << "[" << lineNumber << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
                for (const auto& hex : hexValues) {
                    output << hex << " ";
                }
                output << std::endl;
                lineNumber++; // Tăng lineNumber ở đây

                // Đặt lại cờ cho lần phát hiện khác biệt tiếp theo
                foundDifference = false; // Đặt lại cờ
            }
        }
    }

    // Xuất ra nếu còn giá trị hex chưa đủ 16
    if (foundDifference && !hexValues.empty()) {
        output << "[" << lineNumber << "] // OFFSET: 0x" << std::hex << (currentOffset) << " hex: ";
        for (const auto& hex : hexValues) {
            output << hex << " ";
        }
        output << std::endl;
        lineNumber++; // Tăng lineNumber ở đây
    }

    // Kiểm tra kích thước file
    if (originalBuffer.size() != modifiedBuffer.size()) {
        output << "File sizes differ: Original size: " << originalBuffer.size() 
               << ", Modified size: " << modifiedBuffer.size() << std::endl;
    }

    // Hiển thị thông báo thành công
    showToast(env, context, "Dump Successful");

    // Đóng file
    original.close();
    modified.close();
    output.close();
}

int Checkoffset(JNIEnv *env, jobject context) {
	
	const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
	std::string ori = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/1.bin");
	std::string mod = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/2.bin");
	std::string out = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/offset.txt");
	
   
    compareFiles(ori, mod, out,env,context);

    return 0;
}


#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <string>


void sosanhgiatri() {
    // Xây dựng đường dẫn tệp gốc và tệp chỉnh sửa
    std::string ori = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/1.bin");
    std::string mod = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/2.bin");

    // Đường dẫn lưu kết quả vào tệp
    std::string output_path = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/offset.txt");

    // Mở tệp gốc và tệp đã chỉnh sửa
    std::ifstream ori_file(ori, std::ios::binary);
    std::ifstream mod_file(mod, std::ios::binary);

    // Kiểm tra nếu tệp không mở được
    if (!ori_file.is_open() || !mod_file.is_open()) {
        std::cerr << "Không thể mở một trong các tệp!" << std::endl;
        return;
    }

    // Mở tệp output để ghi kết quả
    std::ofstream output_file(output_path);

    // Kiểm tra nếu tệp output không mở được
    if (!output_file.is_open()) {
        std::cerr << "Không thể mở tệp output để ghi!" << std::endl;
        return;
    }

    // Lấy kích thước của các tệp
    ori_file.seekg(0, std::ios::end);
    mod_file.seekg(0, std::ios::end);
    std::streampos original_size = ori_file.tellg();
    std::streampos modify_size = mod_file.tellg();

    // Tính 90% kích thước của tệp nhỏ hơn
    std::streampos compare_size = static_cast<std::streampos>(std::min(original_size, modify_size) * 0.9);

    // Quay lại vị trí đầu của tệp
    ori_file.seekg(0, std::ios::beg);
    mod_file.seekg(0, std::ios::beg);

    std::streampos offset_original = 0;
    std::streampos offset = 0;

    // So sánh dữ liệu
    while (offset_original < compare_size) {
        // Đọc 2 byte từ mỗi tệp
        char data1[2], data2[2];
        ori_file.read(data1, 2);
        mod_file.read(data2, 2);

        // Kiểm tra nếu đã hết dữ liệu trong một trong các tệp
        if (ori_file.gcount() == 0 || mod_file.gcount() == 0) {
            break;  // Kết thúc nếu một trong các tệp đã hết
        }

        offset_original += offset;
        offset = 0;

        // Nếu hai byte khác nhau
        if (std::memcmp(data1, data2, 2) != 0) {
            std::vector<unsigned char> different_bytes;
            different_bytes.insert(different_bytes.end(), data2, data2 + 2);

            while (true) {
                // Đọc thêm 2 byte từ mỗi tệp
                char arraybyte[2], array_2[2];
                ori_file.read(arraybyte, 2);
                mod_file.read(array_2, 2);

                if (ori_file.gcount() == 0 || mod_file.gcount() == 0) {
                    break;  // Kết thúc nếu một trong các tệp đã hết
                }

                // Nếu hai byte giống nhau
                if (std::memcmp(arraybyte, array_2, 2) == 0) {
                    offset += 2;
                    break;
                } else {
                    different_bytes.insert(different_bytes.end(), array_2, array_2 + 2);
                    offset += 2;
                }
            }

            // Chuyển các byte khác biệt thành chuỗi hex
            std::stringstream hex_d;
            for (unsigned char byte : different_bytes) {
                hex_d << std::uppercase << std::hex << std::setw(2) << std::setfill('0') << (unsigned int)byte << " ";
            }

            // Tính offset trong hệ thập lục phân
            std::stringstream address;
            address << "0x" << std::hex << std::setw(7) << std::setfill('0') << offset_original;

            // Ghi kết quả vào tệp output
            output_file << "// OFFSET: " << address.str() << " HEX: " << hex_d.str() << std::endl;
        }

        offset_original += 2;
    }

    // Đóng các tệp
    ori_file.close();
    mod_file.close();
    output_file.close();
}




#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <regex>

// Hàm trích xuất offset và HEX từ dòng dạng // OFFSET: 0x10406d0 HEX: 00 00 A0 E3 1E FF 2F E1
std::pair<std::string, std::string> extractOffsetAndHex(const std::string& line) {
    std::regex offsetRegex("// OFFSET: (0x[0-9A-Fa-f]+) HEX: ([0-9A-Fa-f ]+)");
    std::smatch match;
    
    if (std::regex_search(line, match, offsetRegex) && match.size() > 2) {
        return {match.str(1), match.str(2)}; // Trả về offset và HEX
    }
    return {"", ""}; // Nếu không tìm thấy, trả về cặp rỗng
}

void extractOffsets(const std::string& offsetsFile, const std::string& dumpFile, const std::string& outputFile) {
    std::ifstream offsetStream(offsetsFile);
    std::ifstream dumpStream(dumpFile);
    std::ofstream outputStream(outputFile);

    if (!offsetStream.is_open() || !dumpStream.is_open() || !outputStream.is_open()) {
        std::cerr << "Error opening files." << std::endl;
        return;
    }

    std::string line;
    std::vector<std::pair<std::string, std::string>> offsets; // Lưu offset và HEX

    // Đọc tất cả các offset và HEX từ file offset.txt
    while (std::getline(offsetStream, line)) {
        auto [offset, hex] = extractOffsetAndHex(line);
        if (!offset.empty()) {
            offsets.push_back({offset, hex});
        }
    }

    // Tìm kiếm từng offset trong file Dump.cs
    while (std::getline(dumpStream, line)) {
        for (const auto& [offset, hex] : offsets) {
            if (line.find(offset) != std::string::npos) {
                // Xuất dòng chứa offset và HEX tương ứng
                outputStream << "// OFFSET: " << offset << " HEX: " << hex << std::endl;
                //outputStream << line << std::endl;

                // Xuất 3 dòng tiếp theo
                for (int i = 0; i < 4; ++i) {
                    if (std::getline(dumpStream, line)) {
                        outputStream << line << std::endl;
                    }
                }
                outputStream << std::endl; // Thêm dòng trống giữa các mục
                break; // Thoát khỏi vòng lặp để không lặp lại các offset
            }
        }
    }

    offsetStream.close();
    dumpStream.close();
    outputStream.close();

    // Hiển thị thông báo
    //showToast(env, context, "Dump Successful");
}




int Exstruct() {
    const char* packageNameCStr = GetPackageNameH();
    char filePath[512];
    
    std::string off = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/offset.txt");
    std::string dump = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/").append(GetPackageNameH()).append(" [X64].cs");
    std::string out = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/struct.txt");


    extractOffsets(off, dump, out);

    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_android_tool_Menu_GetPack(JNIEnv* env, jobject /* this */) {
    // Gọi hàm GetPackageNameH để lấy tên gói
    const char* packageName = GetPackageNameH();

    // Chuyển đổi từ const char* sang jstring
    return env->NewStringUTF(packageName);
}


void DeleteFiles() {
    // Đường dẫn đến file ori và mod
    std::string ori = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/1.bin");
    std::string mod = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/2.bin");

    // Xóa file ori
    if (remove(ori.c_str()) == 0) {
        std::cout << "File " << ori << " đã được xóa thành công." << std::endl;
    } else {
        std::cerr << "Không thể xóa file " << ori << ". Lỗi: " << strerror(errno) << std::endl;
    }

    // Xóa file mod
    if (remove(mod.c_str()) == 0) {
        std::cout << "File " << mod << " đã được xóa thành công." << std::endl;
    } else {
        std::cerr << "Không thể xóa file " << mod << ". Lỗi: " << strerror(errno) << std::endl;
    }
}



