#pragma once

#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac) { 
    origInput(thiz, ex_ab, ex_ac);
	ImGui_ImplAndroid_HandleTouchEvent((AInputEvent *)thiz, {(float) screenWidth / (float) glWidth, (float) screenHeight / (float) glHeight});
    return;
}

int32_t (*orig_ANativeWindow_getWidth)(ANativeWindow* window);
int32_t _ANativeWindow_getWidth(ANativeWindow* window) {
	screenWidth = orig_ANativeWindow_getWidth(window);
	return orig_ANativeWindow_getWidth(window);
}

int32_t (*orig_ANativeWindow_getHeight)(ANativeWindow* window);
int32_t _ANativeWindow_getHeight(ANativeWindow* window) {
	screenHeight = orig_ANativeWindow_getHeight(window);
	return orig_ANativeWindow_getHeight(window);
}

#if defined(__aarch64__) 
    #define RETURN OBFUSCATE("CO 03 5F D6");
    #define TRUE OBFUSCATE("20 00 80 D2 CO 03 5F D6")
    #define FALSE OBFUSCATE("00 00 80 D2 CO 03 5F D6")
    auto androidDataPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageName()).append("/").append(GetPackageName()).append(" [X64]").append(".cs");
#else
    #define RETURN OBFUSCATE("1E FF 2F E1")
    #define TRUE OBFUSCATE("01 00 A0 E3 1E FF 2F E1")
    #define FALSE OBFUSCATE("00 00 A0 E3 1E FF 2F E1")
    auto androidDataPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageName()).append("/").append(GetPackageName()).append(" [X32]").append(".cs");
#endif

uintptr_t energy;
bool Esp, EspLine, EspBox, EspHp, EspAlert, EspCount, EspDistance, EspPosition;
bool Move, See, Hear, Health, Energy;
float MoveSpeed = 4;
int Width, Height;
static int Box = 0;
bool NormalBox, CornerBox, Box3D;
vector<void*> players;

void clearPlayers() {
    vector<void*> deadPlayers;
    for (int i = 0; i < players.size(); i++) {
        void* player = players[i];
        if (player != NULL && IsPlayerDead(player)) {
            deadPlayers.push_back(player);
        }
    }
    for (int i = 0; i < deadPlayers.size(); i++) {
        players.erase(remove(players.begin(), players.end(), deadPlayers[i]), players.end());
    }
}

bool playerFind(void *pl) {
    if (pl != NULL) {
        for (int i = 0; i < players.size(); i++) {
            if (pl == players[i]) return true;
        }
    }
    return false;
}

void (*org_EntityListUpdate)(void *player);
void new_EntityListUpdate(void *player) {
    if (player != NULL) {
        if (!playerFind(player)) players.push_back(player);
        if (players.size() > 15) {
            players.clear();
        }
    }
    clearPlayers();
    if (org_EntityListUpdate != NULL) {
        org_EntityListUpdate(player);
    }
}

bool (*_canNotMove)(void* instance);
bool canNotMove(void *instance){
    if (instance != NULL && Move){
        return true;
    }
    return _canNotMove(instance);
}

bool (*_canHear)(void* instance);
bool canHear(void *instance){
    if (instance != NULL && See){
        return false;
    }
    return _canHear(instance);
}

bool (*_canSee)(void* instance);
bool canSee(void *instance){
    if (instance != NULL && See){
        return false;
    }
    return _canSee(instance);
}

float (*_moveSpeed)(void* instance);
float moveSpeed(void *instance){
    if (instance != NULL && MoveSpeed > 4){
        return MoveSpeed;
    }
    return _moveSpeed(instance);
}

float (*_playerHealth)(void* instance);
float playerHealth(void *instance){
    if (instance != NULL && Health){
        return 1000;
    }
    return _playerHealth(instance);
}

void (*_playerUpdate)(void* instance);
void playerUpdate(void *instance){
    if (instance != NULL){
    if (Energy) *(float *)((uint64_t) instance + energy) = 100;
    }
    return _playerUpdate(instance);
}

void DrawESP(ImDrawList *draw){
     if(Esp){
        for (int i = 0; i < players.size(); i++) {      
        void *isEntityList;   
        if (i < players.size()) isEntityList = players[i]; else return;
        Vector3 EnemyPos = getPosition(isEntityList);
        Vector3 MyPos = getPosition(get_camera());
        auto EnemyPosition = worldToScreen(get_camera(), EnemyPos);
        Vector2 RootPosition = Vector2(glWidth - (glWidth - EnemyPosition.x) + 5, EnemyPosition.y);
        if (EnemyPosition.z > 0) RootPosition = Vector2(EnemyPosition.x, glHeight - EnemyPosition.y);
        if (EnemyPosition.z < 1.f) continue;
        Vector2 HeadPosition = Vector2(glWidth - (glWidth - EnemyPosition.x) + 5, glHeight - EnemyPosition.y - (glHeight / 6.35));
        float distance = Vector3::Distance(MyPos, EnemyPos);
        
        if(EspLine){
        draw->AddLine(ImVec2(glWidth /2, 80), ImVec2(RootPosition.x, RootPosition.y), IM_COL32(255, 255, 255, 255), 1.7f);
        draw->AddCircleFilled(ImVec2(RootPosition.x, RootPosition.y), 7, IM_COL32(0, 255, 0, 255));
        }
        
        if (EspBox){
        float boxHeight = abs(HeadPosition.y - RootPosition.y);
        float boxWidth = boxHeight * 0.75f;
        ImVec2 vStart = {HeadPosition.x - (boxWidth / 2.f), HeadPosition.y};
        ImVec2 vEnd = {vStart.x + boxWidth, vStart.y + boxHeight};
        if (NormalBox) draw->AddRect(vStart, vEnd, IM_COL32(255, 255, 255, 255), 0, 240, 1.7f);
        if (CornerBox) ESP::drawCornerBox(HeadPosition.x - (boxWidth / 2.f), HeadPosition.y, boxWidth, boxHeight, 1.7f, IM_COL32(255, 255, 255, 255));
        if (Box3D) ESP::Draw3dBox(EnemyPos, get_camera(), glWidth, glHeight, 1.7f, IM_COL32(255, 255, 255, 255));
        }
        
        if (EspDistance){
        std::string strDistance = to_string((int)distance) + "M";
        draw->AddText(NULL, ((float) glHeight / 35.0f), {RootPosition.x - 35, RootPosition.y - 30}, IM_COL32(0, 255, 0, 255), strDistance.c_str());
        }
        
        if (EspCount){
        int Count = players.size();
        std::string Allplayers = to_string(Count);
        draw->AddCircleFilled(ImVec2(glWidth / 2, 70), 25, IM_COL32(255, 255, 255, 150));
        if (Count <= 9) draw->AddText(NULL, ((float) glHeight / 39.0f), {glWidth / 2 - 6.25, 55}, IM_COL32(0, 0, 0, 255), Allplayers.c_str());
        if (Count >= 10) draw->AddText(NULL, ((float) glHeight / 39.0f), {glWidth / 2 - 3, 55}, IM_COL32(0, 0, 0, 255), Allplayers.c_str());
        }
        
        if(EspPosition){
        std::string entityX = "X: " + to_string(EnemyPos.x);
        std::string entityY = "Y: " + to_string(EnemyPos.y);
        std::string entityZ = "Z: " + to_string(EnemyPos.z);
        draw->AddText(NULL, ((float) glHeight / 35.0f), {RootPosition.x - 180, RootPosition.y - 150}, IM_COL32(255, 255, 255, 255), entityX.c_str());
        draw->AddText(NULL, ((float) glHeight / 35.0f), {RootPosition.x - 180, RootPosition.y - 120}, IM_COL32(255, 255, 255, 255), entityY.c_str());
        draw->AddText(NULL, ((float) glHeight / 35.0f), {RootPosition.x - 180, RootPosition.y - 90}, IM_COL32(255, 255, 255, 255), entityZ.c_str());
        }
        
        }
    }
}
