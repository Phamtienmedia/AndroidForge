#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <KittyMemory/KittyMemory.h>
#include <KittyMemory/MemoryPatch.h>
#include <KittyMemory/KittyScanner.h>
#include <KittyMemory/KittyUtils.h>
#include "Includes/obfuscate.h"
#include "Includes/Logger.h"
#include "Includes/Macros.h"
#include "Includes/Utils.h"
#include "TuanMeta/Call_Me.h"
#include "Hook.h"
#include "Dumper.h"
#define RealLibToLoad "libDumper.so"
bool setup = false;


bool il2Loaded;

// Function to read the library path from a file
std::string ReadLibFromFile(const std::string& filePath) {
    std::ifstream file(filePath);
    std::string libPath;

    if (file.is_open()) {
        std::getline(file, libPath);  // Read the first line as the library path
        file.close();
    } else {
        std::cerr << "Failed to open file: " << filePath << std::endl;
    }

    return libPath;
}

int ReadIntFromFile(const std::string& filePath) {
    std::ifstream file(filePath);  // Mở file để đọc
    int value = 0;

    if (file.is_open()) {
        file >> value;  // Đọc giá trị int từ file
        file.close();  // Đóng file sau khi đọc
    } else {
        std::cerr << "Không thể mở file: " << filePath << std::endl;
    }

    return value;
}



bool CreateLibDumpFileIfNeeded(const std::string& filePath) {
    // Kiểm tra xem file có tồn tại không
    std::ifstream file(filePath);
    if (!file) {
        // Nếu không tồn tại, tạo file mới và ghi một đường dẫn mặc định vào
        std::ofstream newFile(filePath);
        if (newFile) {
            newFile << "libil2cpp.so";  // Đặt đường dẫn mặc định của lib ở đây
            newFile.close();
            std::cout << "File libdump.txt đã được tạo." << std::endl;
            return true;
        } else {
            std::cerr << "Không thể tạo file libdump.txt!" << std::endl;
            return false;
        }
    }
file.close();
    return true;
}

bool CreateDelay(const std::string& filePath) {
    // Kiểm tra xem file có tồn tại không
    std::ifstream file(filePath);
    if (!file) {
        // Nếu không tồn tại, tạo file mới và ghi một đường dẫn mặc định vào
        std::ofstream newFile(filePath);
        if (newFile) {
            newFile << "5";  // Đặt đường dẫn mặc định của lib ở đây
            newFile.close();
            std::cout << "File libdump.txt đã được tạo." << std::endl;
            return true;
        } else {
            std::cerr << "Không thể tạo file libdump.txt!" << std::endl;
            return false;
        }
    }
file.close();
    return true;
}

bool FileExists(const std::string& filePath) {
    std::ifstream file(filePath);
    return file.is_open();  // Nếu file mở thành công, file tồn tại
}

struct MemRegion {
    uint64_t start;
    uint64_t end;
    std::string perms;
    std::string path;
};
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <fcntl.h>

struct ModuleAddr {
    uintptr_t start;
    uintptr_t end;
};

ModuleAddr get_module_range(const char* module_name) {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return {0, 0};

    uintptr_t start = 0, end = 0;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, module_name)) {
            sscanf(line, "%lx-%lx", &start, &end);
            break;
        }
    }
    fclose(fp);
    return {start, end};
}
std::vector<MemRegion> getRegions(const std::string& libname) {
    std::vector<MemRegion> regions;
    std::ifstream maps("/proc/self/maps");
    std::string line;

    while (std::getline(maps, line)) {
        if (line.find(libname) != std::string::npos) {
            MemRegion region{};
            std::stringstream ss(line);
            std::string addr, perms, offset, dev, inode, path;

            ss >> addr >> perms >> offset >> dev >> inode;
            std::getline(ss, path);

            if (!path.empty() && path[0] == ' ')
                path = path.substr(1);

            size_t dash = addr.find('-');
            if (dash == std::string::npos) continue;

            region.start = std::stoull(addr.substr(0, dash), nullptr, 16);
            region.end   = std::stoull(addr.substr(dash + 1), nullptr, 16);
            region.perms = perms;
            region.path  = path;

            regions.push_back(region);
        }
    }
    return regions;
}

// Giả lập LOG nếu code của bạn chưa có, xóa đoạn này nếu đã có LOGE, LOGI...
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "DUMP", __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "DUMP", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "DUMP", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "DUMP", __VA_ARGS__)

// Định nghĩa cấu trúc vùng nhớ

// Tự định nghĩa cấu trúc iovec vì AIDE có thể thiếu header này
struct local_iovec {
    void  *iov_base;    /* Starting address */
    size_t iov_len;     /* Number of bytes to transfer */
};

// Định nghĩa mã Syscall theo từng kiến trúc chip (Bắt buộc cho AIDE)
#ifndef __NR_process_vm_readv
    #if defined(__arm__)
        #define __NR_process_vm_readv 376
    #elif defined(__aarch64__)
        #define __NR_process_vm_readv 270
    #elif defined(__i386__)
        #define __NR_process_vm_readv 347
    #elif defined(__x86_64__)
        #define __NR_process_vm_readv 310
    #endif
#endif

// Hàm đọc bộ nhớ an toàn tự chế - Vượt qua mọi giới hạn của AIDE
bool safeReadMemoryAlternative(pid_t pid, uint64_t remoteAddr, void* localBuf, size_t size) {
    struct local_iovec localKey;
    struct local_iovec remoteKey;

    localKey.iov_base = localBuf;
    localKey.iov_len = size;
    remoteKey.iov_base = reinterpret_cast<void*>(remoteAddr);
    remoteKey.iov_len = size;

    // Gọi trực tiếp xuống Kernel thông qua số hiệu syscall
    long bytesRead = syscall(__NR_process_vm_readv, pid, &localKey, 1, &remoteKey, 1, 0);
    return bytesRead == static_cast<long>(size);
}


#include <link.h> // Bắt buộc phải có để dùng dl_iterate_phdr và dl_phdr_info

// Cấu trúc để truyền dữ liệu vào Callback
struct BaseSearchTarget {
    const char* targetLibName;
    uint64_t foundBaseAddr;
};

// Hàm callback tiêu chuẩn để tìm Base Address chính xác từ hệ thống
int findBaseAddressCallback(struct dl_phdr_info *info, size_t size, void *data) {
    BaseSearchTarget* target = reinterpret_cast<BaseSearchTarget*>(data);
    
    // Kiểm tra tên thư viện (Ví dụ: "libil2cpp.so")
    if (info->dlpi_name != nullptr && strstr(info->dlpi_name, target->targetLibName)) {
        target->foundBaseAddr = info->dlpi_addr; 
        return 1; // Tìm thấy thì dừng vòng lặp dl_iterate_phdr
    }
    return 0; // Tiếp tục tìm kiếm
}

void dumpRegionsNormalized(const std::vector<MemRegion>& regions, const std::string& outfile, const std::string& libName) {
    if (regions.empty()) {
        LOGE("No regions found!");
        return;
    }

    // 1. TÌM BASE ADDRESS CHUẨN BẰNG DL_ITERATE_PHDR
    BaseSearchTarget target = { libName.c_str(), 0 };
    dl_iterate_phdr(findBaseAddressCallback, &target);

    uint64_t baseAddr = target.foundBaseAddr;

    // Phân tách trường hợp dự phòng (Fallback) nếu dl_iterate_phdr thất bại
    if (baseAddr == 0) {
        LOGW("[BASE] dl_iterate_phdr failed! Falling back to original logic...");
        baseAddr = UINT64_MAX;
        for (const auto& r : regions) {
            if (r.perms.find("r") != std::string::npos && r.start < baseAddr) {
                baseAddr = r.start;
            }
        }
    }

    if (baseAddr == UINT64_MAX || baseAddr == 0) {
        LOGE("[BASE] Invalid base address calculated!");
        return;
    }
    LOGI("[BASE] Base selected via Linker: 0x%llx", (unsigned long long)baseAddr);

    // Mở file ghi (sẽ tự động xóa nội dung cũ nếu có)
    std::ofstream out(outfile, std::ios::binary | std::ios::out | std::ios::trunc);
    if (!out.is_open()) {
        LOGE("[FILE] Cannot open output file: %s", outfile.c_str());
        return;
    }

    pid_t myPid = getpid();
    size_t totalDumpedSize = 0;

    // 2. Lặp qua từng vùng để dump và tái cấu trúc offset
    for (const auto& r : regions) {
        if (r.perms.find("r") == std::string::npos) {
            continue; 
        }

        // Bỏ qua các vùng nhớ nằm TRƯỚC Base chuẩn (Tránh việc offset ra số âm cực lớn gây lỗi 4GB)
        if (r.start < baseAddr) {
            continue;
        }

        size_t size = r.end - r.start;
        if (size == 0) continue;

        uint64_t offset = r.start - baseAddr;
        std::vector<char> buffer(size);

        // Đọc bộ nhớ an toàn
        if (!safeReadMemoryAlternative(myPid, r.start, buffer.data(), size)) {
            try {
                std::memcpy(buffer.data(), reinterpret_cast<void*>(r.start), size);
            } catch (...) {
                LOGE("[SKIP] Cannot read region: 0x%llx", (unsigned long long)r.start);
                continue;
            }
        }

        // 3. Khôi phục đúng cấu trúc sơ đồ phân đoạn
        out.seekp(offset, std::ios::beg);
        if (!out) {
            LOGE("[ERROR] seekp failed at offset 0x%llx", (unsigned long long)offset);
            continue;
        }

        out.write(buffer.data(), size);
        if (!out) {
            LOGE("[ERROR] write failed at offset 0x%llx", (unsigned long long)offset);
            continue;
        }

        totalDumpedSize += size;
    }

    out.flush();
    out.close();

    // 4. Kiểm tra kích thước file thật sau khi lưu thành công
    struct stat st;
    if (stat(outfile.c_str(), &st) == 0) {
        LOGI("[DONE] Dump thành công! Kích thước file thực tế: %.2f MB", st.st_size / 1024.0 / 1024.0);
    }
}


 std::vector<MemRegion> regions;
std::vector<MemRegion> regions2;
// Dump libil2cpp.so
    std::string libname = "libil2cpp.so";   // đổi nếu muốn lib khác
    std::string outfile = "/storage/emulated/0/Android/data/com.garena.game.kgvn64/1.bin";
    std::string outfile2 = "/storage/emulated/0/Android/data/com.vtc.duymomo/2.bin";
   
    
uintptr_t il2cppMap;
ProcMap anogsMap, il2cppMap2;


//========= LOAD THREAD OK ==========


void *Init_Thread(void *) {
//sleep(1);
std::string directoryPath = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/libdump.txt");
std::string dump = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/").append(GetPackageNameH()).append(" [X64].cs");
std::string delaydir = std::string("/storage/emulated/0/Android/data/").append(GetPackageNameH()).append("/delay.txt");


if (!CreateLibDumpFileIfNeeded(directoryPath)) {
        return nullptr;  // Nếu không thể tạo file, thoát
    }
if (!CreateDelay(delaydir)) {
        return nullptr;  // Nếu không thể tạo file, thoát
    }   
 
    LOGD("dang dump");
int delay = ReadIntFromFile(delaydir);
//sleep(4);
std::string libPath = ReadLibFromFile(directoryPath);
/*if (libPath.empty()) {
        std::cerr << "Failed to read lib path from file!" << std::endl;
        return nullptr;}
 do {
        sleep(0);
    } while (!isLibraryLoaded(libPath.c_str()));
//auto il2cpp_handle = dlopen("libil2cpp.so", 4);*/
const char* libName = libPath.c_str();
while (true) {
        regions = getRegions(libName);
        if (!regions.empty()) break;
       
        LOGD("Đang chờ libil2cpp.so được load...");
        sleep(1);
    }
    
    
   /* 
    while (true)
{
    regions = getRegions(libName);

    if (!regions.empty())
        break;

    LOGD("Đang chờ libil2cpp.so được load...");
    sleep(1);
}
    */
	
    
    
dumpRegionsNormalized(regions, SaveCustom("1.bin"),libName);
sleep(5);


sleep(delay);


dumpRegionsNormalized(regions, SaveCustom("2.bin"),libName);
sosanhgiatri();
//Exstruct();	
//DeleteFiles();

  //  IL2Cpp::Il2CppAttach();
       return nullptr;
}

/*
void *pLibRealUnity = 0;

typedef jint(JNICALL *CallJNI_OnLoad_t)(JavaVM *vm, void *reserved);

typedef void(JNICALL *CallJNI_OnUnload_t)(JavaVM *vm, void *reserved);

CallJNI_OnLoad_t RealJNIOnLoad = 0;
CallJNI_OnUnload_t RealJNIOnUnload = 0;

JNIEXPORT jint JNICALL CallJNIOL(
        JavaVM *vm, void *reserved) {
    LOGI("Exec %s", RealLibToLoad);
    if (!pLibRealUnity)
        pLibRealUnity = dlopen(RealLibToLoad, RTLD_NOW);
    if (!RealJNIOnLoad)
        RealJNIOnLoad = reinterpret_cast<CallJNI_OnLoad_t>(dlsym(pLibRealUnity, "JNI_OnLoad"));
    return RealJNIOnLoad(vm, reserved);
}

JNIEXPORT void JNICALL CallJNIUL(
        JavaVM *vm, void *reserved) {
    if (!pLibRealUnity)
        pLibRealUnity = dlopen(RealLibToLoad, RTLD_NOW);
    if (!RealJNIOnUnload)
        RealJNIOnUnload = reinterpret_cast<CallJNI_OnUnload_t>(dlsym(pLibRealUnity,
                                                                     "JNI_OnUnload"));
    RealJNIOnUnload(vm, reserved);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    LOGI("Initialize JNI");

    return CallJNIOL(vm, reserved);
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
    LOGI("Unload JNI");

    CallJNIUL(vm, reserved);
}*/


JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    if (vm != NULL) {
    //jvm = vm;
    }
    vm->GetEnv((void**)&env, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
   // return CallJNIOL(vm, reserved);
}


__attribute__((constructor))
void lib_main()
{
	//Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getWidth")), (void *) _ANativeWindow_getWidth, (void **) &orig_ANativeWindow_getWidth);
	//Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libandroid.so"), OBFUSCATE("ANativeWindow_getHeight")), (void *) _ANativeWindow_getHeight, (void **) &orig_ANativeWindow_getHeight);
  //  Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libinput.so"), OBFUSCATE("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE")), (void *) myInput, (void **) &origInput);
//    Tools::Hook((void *) DobbySymbolResolver(OBFUSCATE("/system/lib/libEGL.so"), OBFUSCATE("eglSwapBuffers")), (void *) _eglSwapBuffers, (void **) &orig_eglSwapBuffers);
	pthread_t myThread;
	pthread_create(&myThread, NULL, Init_Thread, NULL);
}
